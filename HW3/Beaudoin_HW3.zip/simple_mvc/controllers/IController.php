<?php
interface IController
{
    public function indexAction($vars);
    public function getName();
}
?>
