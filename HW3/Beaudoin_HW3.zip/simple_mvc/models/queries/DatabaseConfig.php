<?php
class DatabaseConfig
{
    public $dbType;
    public $dbHost;
    public $dbName;
    public $dbUser;
    public $dbPass;
}
?>
